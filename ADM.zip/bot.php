<?php
// توکن ربات شما
$token = "7017580733:AAH8xy0bBJ0vY7kc19YMlUyFSUD6pmAkpYE";
$apiURL = "https://api.telegram.org/bot$token/";

// دریافت آپدیت‌ها از تلگرام
$update = file_get_contents("php://input");
$update = json_decode($update, TRUE);

// استخراج اطلاعات پیام
$chatId = $update["message"]["chat"]["id"];
$message = $update["message"]["text"];

// بررسی دستور /start
if ($message == "/start") {
    $keyboard = [
        'inline_keyboard' => [
            [
                ['text' => 'Click here', 'url' => 'https://example.com']
            ]
        ]
    ];
    $keyboard = json_encode($keyboard);

    $message = "Welcome! Click the button below.";

    // ارسال پیام به کاربر
    file_get_contents($apiURL . "sendMessage?chat_id=" . $chatId . "&text=" . urlencode($message) . "&reply_markup=" . $keyboard);
}
?>
