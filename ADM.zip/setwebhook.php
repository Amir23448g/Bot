<?php
$token = "7017580733:AAH8xy0bBJ0vY7kc19YMlUyFSUD6pmAkpYE";
$url = "https://your-domain.com/bot.php"; // آدرس URL که فایل bot.php در آن قرار دارد

file_get_contents("https://api.telegram.org/bot$token/setWebhook?url=$url");
echo "Webhook set: $url";
?>
